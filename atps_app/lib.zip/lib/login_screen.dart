import 'package:flutter/material.dart';
import 'package:signals_flutter/signals_flutter.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'atps_store.dart';
import 'admin_signup_screen.dart';
import 'main.dart'; 
import 'admin_dashboard.dart';
import 'signup_screen.dart'; 

class LoginScreen extends StatefulWidget {
  final String role; 
  const LoginScreen({super.key, required this.role});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final store = AtpsStore(); 

  void _handleLogin() async {
    final username = _usernameController.text;
    final password = _passwordController.text;

    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please enter username and password"), backgroundColor: Colors.red));
      return;
    }

    bool success = await store.login(username, password, widget.role);

    if (success && mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => widget.role == "ADMIN" ? const AdminDashboard() : const DriverDashboard()));
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Invalid Credentials"), backgroundColor: Colors.red));
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isAdmin = widget.role == "ADMIN";
    return Scaffold(
      backgroundColor: const Color(0xFF0B0E14),
      appBar: AppBar(backgroundColor: const Color(0xFF0B0E14), leading: const BackButton(color: Colors.grey), elevation: 0),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: isAdmin ? Colors.blueAccent.withOpacity(0.1) : Colors.redAccent.withOpacity(0.1), shape: BoxShape.circle),
                child: Icon(isAdmin ? LucideIcons.shield : Icons.local_hospital, size: 60, color: isAdmin ? Colors.blueAccent : Colors.redAccent)),
              const SizedBox(height: 30),
              Text(isAdmin ? "Admin Portal" : "Driver Login", style: GoogleFonts.inter(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white)),
              const SizedBox(height: 40),
              _buildTextField("Username / ID", LucideIcons.user, _usernameController),
              const SizedBox(height: 20),
              _buildTextField("Password", LucideIcons.lock, _passwordController, isPassword: true),
              const SizedBox(height: 40),
              Watch((context) => SizedBox(width: double.infinity, height: 55, child: ElevatedButton(
                onPressed: store.isLoading.value ? null : _handleLogin,
                style: ElevatedButton.styleFrom(backgroundColor: isAdmin ? Colors.blueAccent : Colors.redAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: store.isLoading.value ? const CircularProgressIndicator(color: Colors.white) : const Text("LOGIN", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ))),
              // --- REGISTER LINKS ---
const SizedBox(height: 24),

if (!isAdmin) ...[
  // Driver Registration Link
  Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      const Text(
        "Don't have an account? ",
        style: TextStyle(color: Colors.grey),
      ),
      GestureDetector(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const SignupScreen()),
        ),
        child: const Text(
          "Register Unit",
          style: TextStyle(
            color: Colors.blueAccent,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    ],
  )
] else ...[
  // Admin Registration Link
  Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      const Text(
        "New Officer? ",
        style: TextStyle(color: Colors.grey),
      ),
      GestureDetector(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const AdminSignupScreen()),
        ),
        child: const Text(
          "Register Cyber Cell",
          style: TextStyle(
            color: Colors.blueAccent,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    ],
  )
]

              ]
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, IconData icon, TextEditingController controller, {bool isPassword = false}) {
    return TextField(
      controller: controller, obscureText: isPassword, style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(labelText: label, labelStyle: const TextStyle(color: Colors.grey), prefixIcon: Icon(icon, color: Colors.grey), filled: true, fillColor: const Color(0xFF151B25), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
    );
  }
}