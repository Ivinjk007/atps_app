import 'package:flutter/material.dart';
import 'package:signals_flutter/signals_flutter.dart';
import 'traffic_service.dart';

class AtpsStore {
  final _api = TrafficService();

  // =========================
  // DRIVER STATE
  // =========================

  final status = signal("RED");
  final isLoading = signal(false);
  final unitId = signal("AMB-042");
  final eta = signal("8:45");

  // =========================
  // ADMIN STATE
  // =========================

  final emergencyRequests = listSignal<Map<String, dynamic>>([
    {
      "id": "REQ-01",
      "unit": "AMB-042",
      "location": "Main St & 5th",
      "status": "PENDING",
      "type": "CRITICAL",
      "eta": "2 min"
    },
    {
      "id": "REQ-02",
      "unit": "FIRE-09",
      "location": "Broadway & 2nd",
      "status": "APPROVED",
      "type": "HIGH",
      "eta": "5 min"
    },
    {
      "id": "REQ-03",
      "unit": "POL-101",
      "location": "Oak Ave",
      "status": "COMPLETED",
      "type": "MEDIUM",
      "eta": "12 min"
    },
  ]);

  final trafficSignals = listSignal<Map<String, dynamic>>([
    {
      "id": "SIG-01",
      "name": "Main St & 5th",
      "status": "RED",
      "online": true
    },
    {
      "id": "SIG-02",
      "name": "Broadway & 2nd",
      "status": "GREEN",
      "online": true
    },
    {
      "id": "SIG-03",
      "name": "Oak Ave & Pine",
      "status": "RED",
      "online": true
    },
    {
      "id": "SIG-04",
      "name": "Central Blvd",
      "status": "RED",
      "online": false
    },
  ]);

  // =========================
  // COMPUTED VALUES
  // =========================

  late final statusColor = computed(
      () => status.value == "GREEN"
          ? const Color(0xFF00CC66)
          : const Color(0xFFFF4D4D));

  late final statusText = computed(
      () => status.value == "GREEN"
          ? "PRIORITY ACTIVE"
          : "NORMAL OPERATION");

  late final signalText =
      computed(() => status.value == "GREEN" ? "GREEN" : "RED");

  late final activeEmergenciesCount = computed(
      () => emergencyRequests.where((r) => r['status'] == 'APPROVED').length);

  late final pendingRequestsCount = computed(
      () => emergencyRequests.where((r) => r['status'] == 'PENDING').length);

  // =========================
  // TRAFFIC ACTIONS
  // =========================

  Future<void> requestPriority() async {
    if (status.value == "GREEN") return;

    isLoading.value = true;
    await _api.requestGreen(unitId.value);
    status.value = "GREEN";
    isLoading.value = false;
  }

  Future<void> reset() async {
    isLoading.value = true;
    await _api.resetSignal();
    status.value = "RED";
    isLoading.value = false;
  }

  // --- ACTIONS: ADMIN ---
  void approveRequest(String id) {
    final index = emergencyRequests.indexWhere((element) => element['id'] == id);
    if (index != -1) {
      var req = Map<String, dynamic>.from(emergencyRequests[index]);
      req['status'] = 'APPROVED';
      emergencyRequests[index] = req;
    }
  }

  void denyRequest(String id) {
    final index = emergencyRequests.indexWhere((element) => element['id'] == id);
    if (index != -1) {
      var req = Map<String, dynamic>.from(emergencyRequests[index]);
      req['status'] = 'DENIED';
      emergencyRequests[index] = req;
    }
  }

  void toggleSignalManual(String id) {
    final index = trafficSignals.indexWhere((element) => element['id'] == id);
    if (index != -1) {
      var sig = Map<String, dynamic>.from(trafficSignals[index]);
      sig['status'] = sig['status'] == 'RED' ? 'GREEN' : 'RED';
      trafficSignals[index] = sig;
    }
  }

  // --- ACTIONS: AUTHENTICATION ---

  // 1. Login
  Future<bool> login(String username, String password, String role) async {
    isLoading.value = true;
    final result = await _api.login(username, password, role);
    isLoading.value = false;

    if (result['success'] == true) {
      if (result['user'] != null && result['user']['unit_id'] != null) {
        unitId.value = result['user']['unit_id'];
      }
      return true;
    } else {
      print("Login failed: ${result['message']}");
      return false;
    }
  }

 // 1. Create Driver Account (Updated)
  // Returns NULL if success, or Error Message string if failed
 Future<bool> createAccount(
  String name,
  String username,
  String password,
  String unitId,
  String role,
) async {

    isLoading.value = true;
    
    // Call API
    final result = await _api.signup(name, username, password, unitId, "DRIVER"); 
    
    isLoading.value = false;

    if (result['success'] == true) {
      return true; // Success!
    }  else {
    print("Signup failed: ${result['message']}");
    return false;
    }
  }

  // 2. Create Admin Account (Updated)
  Future<bool> createAdminAccount(
  String name,
  String username,
  String password,
  String cyberId,
) async {

  isLoading.value = true;

  await Future.delayed(const Duration(seconds: 1));

  isLoading.value = false;

  if (!cyberId.startsWith("CYBER-")) {
    return false;
  }

  return true;
}
}