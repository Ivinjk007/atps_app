import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http; 

class TrafficService {
  // --- CONFIGURATION ---
  static const bool useRealServer = true; 
  
  // Your Server URL (Keep this as you set it)
  static const String serverUrl = "http://172.30.29.57:5000/api";

  // --- AUTHENTICATION METHODS ---

  Future<Map<String, dynamic>> login(String username, String password, String role) async {
    if (useRealServer) {
      try {
        final response = await http.post(
          Uri.parse('$serverUrl/login'),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "username": username,
            "password": password,
            "role": role
          }),
        );
        
        if (response.statusCode == 200) {
          return jsonDecode(response.body); // Returns {success: true, user: ...}
        } else {
           final error = jsonDecode(response.body);
           return {"success": false, "message": error['message']};
        }
      } catch (e) {
        print("Server Error: $e");
        return {"success": false, "message": "Cannot connect to server"};
      }
    } else {
      await Future.delayed(const Duration(seconds: 2));
      return {"success": true}; 
    }
  }

  // UPDATED: Now accepts 'role' parameter
  Future<Map<String, dynamic>> signup(String name, String username, String password, String unitId, String role) async {
    if (useRealServer) {
      try {
        final response = await http.post(
          Uri.parse('$serverUrl/signup'),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "name": name,
            "username": username,
            "password": password,
            "unit_id": unitId,
            "role": role // <--- Sends DRIVER or ADMIN to server
          }),
        );

        return jsonDecode(response.body);
      } catch (e) {
        return {"success": false, "message": "Connection Failed"};
      }
    } else {
      await Future.delayed(const Duration(seconds: 2));
      return {"success": true};
    }
  }

  // --- TRAFFIC METHODS ---
  Future<void> requestGreen(String unitId) async {
     await Future.delayed(const Duration(seconds: 2));
  }

  Future<void> resetSignal() async {
     await Future.delayed(const Duration(seconds: 1));
  }
}