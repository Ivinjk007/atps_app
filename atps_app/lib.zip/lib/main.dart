import 'package:flutter/material.dart';
import 'package:signals_flutter/signals_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'atps_store.dart';
import 'login_screen.dart';
import 'guest_dashboard.dart'; 
import 'admin_dashboard.dart'; 
void main() {
  runApp(const AtpsApp());
}

class AtpsApp extends StatelessWidget {
  const AtpsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'APTSC Traffic Control',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B0E14),
        cardColor: const Color(0xFF151B25),
        textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
      ),
      home: const LandingScreen(),
    );
  }
}

// ---------------- SCREEN 1: LANDING ----------------
class LandingScreen extends StatelessWidget {
  const LandingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Row(
          children: [
            Icon(LucideIcons.siren, color: Color(0xFFFF4D4D)),
            SizedBox(width: 10),
            Text(
              "APTSC",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 20),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF00CC66).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFF00CC66).withValues(alpha: 0.3),
              ),
            ),
            child: const Text(
              "System Online",
              style: TextStyle(
                color: Color(0xFF00CC66),
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          )
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Text(
                "Select Your Role",
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                "Access the dashboard designed for your responsibilities",
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 50),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  _buildRoleCard(
                    context,
                    "Ambulance Driver",
                    "Request priority at signals & track routes.",
                    Icons.local_hospital,
                    Colors.redAccent,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const LoginScreen(role: "DRIVER"),
                        ),
                      );
                    },
                  ),

                  _buildRoleCard(
                    context,
                    "Administrator",
                    "Verify emergency requests & control signals.",
                    LucideIcons.shield,
                    Colors.blueAccent,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const LoginScreen(role: "ADMIN"),
                        ),
                      );
                    },
                  ),

                  _buildRoleCard(
                      context,
                      "Guest Viewer",
                      "View real-time system status...",
                      LucideIcons.eye,
                      Colors.cyanAccent,
                      () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const GuestDashboard(),
                          ),
                        );
                      },
                    ),

                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRoleCard(
    BuildContext context,
    String title,
    String desc,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return SizedBox(
      width: 350,
      child: Material(
        color: const Color(0xFF151B25),
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: color, size: 32),
                const SizedBox(height: 20),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  desc,
                  style: const TextStyle(color: Colors.grey, height: 1.5),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Access Dashboard →",
                  style: TextStyle(color: Color(0xFF007BFF)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
 Widget _buildRoleCard(
  BuildContext context,
  String title,
  String description,
  IconData icon,
  Color color,
  VoidCallback onTap,
) {
  return SizedBox(
    width: 320,
    child: Card(
      color: const Color(0xFF151B25),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 32, color: color),
              const SizedBox(height: 20),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                description,
                style: const TextStyle(color: Colors.grey),
              ),
              const Spacer(),
              const Text(
                "Open →",
                style: TextStyle(
                  color: Colors.blueAccent,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

// ---------------- SCREEN 2: DRIVER DASHBOARD ----------------
class DriverDashboard extends StatefulWidget {
  const DriverDashboard({super.key});

  @override
  State<DriverDashboard> createState() => _DriverDashboardState();
}

class _DriverDashboardState extends State<DriverDashboard> {
  final store = AtpsStore();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B0E14),
        title: const Text(
          "Driver Dashboard",
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
        leading: const BackButton(color: Colors.grey),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // STATUS BAR
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF151B25),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "((o)) Connected",
                    style: TextStyle(color: Color(0xFF00CC66)),
                  ),
                  Text(
                    "Unit: ${store.unitId.value}",
                    style: const TextStyle(color: Colors.white70),
                  ),
                  const Text(
                    "GPS Active",
                    style: TextStyle(color: Color(0xFF00CC66)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),

            const Text(
              "Press to request traffic signal priority.",
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 30),

            Watch(
              (context) => GestureDetector(
                onTap: store.requestPriority,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 240,
                  height: 240,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: store.status.value == "GREEN"
                          ? const [
                              Color(0xFF00CC66),
                              Color(0xFF007A3D)
                            ]
                          : const [
                              Color(0xFF1F2937),
                              Color(0xFF111827)
                            ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: store.statusColor.value
                            .withValues(alpha: 0.4),
                        blurRadius: 50,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (store.isLoading.value)
                        const CircularProgressIndicator(color: Colors.white)
                      else ...[
                        Icon(
                          LucideIcons.siren,
                          size: 60,
                          color: store.status.value == "GREEN"
                              ? Colors.white
                              : Colors.white54,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          store.status.value == "GREEN"
                              ? "GRANTED"
                              : "REQUEST",
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                      ]
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 60),

            Row(
              children: [
                Expanded(
                  child: Watch(
                    (context) => _buildInfoCard(
                      "Next Signal",
                      store.signalText.value,
                      store.statusColor.value,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Watch(
                    (context) => _buildInfoCard(
                      "ETA",
                      store.eta.value,
                      Colors.blueAccent,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),
            TextButton(
              onPressed: store.reset,
              child: const Text(
                "Reset Simulation",
                style: TextStyle(color: Colors.white24),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF151B25),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------- GUEST DASHBOARD ----------------

