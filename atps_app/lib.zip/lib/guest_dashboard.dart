import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:google_fonts/google_fonts.dart';

class GuestDashboard extends StatelessWidget {
  const GuestDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B0E14), // Deep Dark Blue
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B0E14),
        title: const Text("Public Traffic View"),
        centerTitle: true,
        leading: const BackButton(color: Colors.grey),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.green.withOpacity(0.3))
            ),
            child: const Row(
              children: [
                Icon(Icons.circle, size: 8, color: Colors.green),
                SizedBox(width: 6),
                Text("LIVE", style: TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold))
              ],
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. PUBLIC ALERT BANNER (Dummy Data)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF007BFF).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF007BFF).withOpacity(0.3))
              ),
              child: const Row(
                children: [
                  Icon(LucideIcons.info, color: Color(0xFF007BFF)),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Active Emergency Corridor", style: TextStyle(color: Color(0xFF007BFF), fontWeight: FontWeight.bold)),
                        SizedBox(height: 4),
                        Text("Please yield on Main St & 5th Ave. Emergency vehicles are approaching.", style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // 2. SIMULATED LIVE MAP
            const Text("Live Traffic Status", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Container(
              height: 320,
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFF151B25),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white10),
                image: const DecorationImage(
                  // A subtle grid pattern to look like a map
                  image: NetworkImage("https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Dark_map.png/640px-Dark_map.png"), // You can replace this with a local asset later
                  fit: BoxFit.cover,
                  opacity: 0.3
                )
              ),
              child: Stack(
                children: [
                  // Dummy Map UI Elements
                  const Positioned(top: 16, right: 16, child: Icon(LucideIcons.layers, color: Colors.white54)),
                  const Positioned(bottom: 16, right: 16, child: Icon(LucideIcons.maximize, color: Colors.white54)),
                  
                  // Simulation Pins (Hospitals, Signals, Ambulances)
                  _buildMapPin(
                      top: 80,
                      left: 60,
                      color: Colors.blue,
                      icon: Icons.local_hospital, // Hospital
                    ),

                    _buildMapPin(
                      top: 150,
                      right: 80,
                      color: Colors.green,
                      icon: Icons.traffic, // Signal Green
                    ),

                    _buildMapPin(
                      bottom: 100,
                      left: 120,
                      color: Colors.red,
                      icon: Icons.traffic, // Signal Red
                    ),
 // Signal Red
                  
                  // Animated Ambulance Pin (Simulation)
                  Positioned(
                    top: 120, left: 180,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.redAccent,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: Colors.redAccent.withOpacity(0.5), blurRadius: 20, spreadRadius: 5)]
                      ),
                      child: const Icon(Icons.local_hospital, color: Colors.white, size: 20),

                    ),
                  ),
                  const Positioned(
                    top: 155, left: 165,
                    child: Text("AMB-042", style: TextStyle(color: Colors.redAccent, fontSize: 10, fontWeight: FontWeight.bold, backgroundColor: Colors.black45))
                  )
                ],
              ),
            ),
            const SizedBox(height: 30),

            // 3. SYSTEM STATS ROW
            Row(
              children: [
                Expanded(child: _buildGuestStat("System Health", "98%", Colors.greenAccent, LucideIcons.activity)),
                const SizedBox(width: 16),
                Expanded(child: _buildGuestStat("Active Signals", "42/50", Colors.white, LucideIcons.zap)),
              ],
            ),
            const SizedBox(height: 30),

            // 4. RECENT ACTIVITY FEED (Dummy Data)
            const Text("Recent Priority Routes", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildActivityItem("Ambulance 042", "Priority granted at Main St.", "2 min ago", Colors.green),
            _buildActivityItem("Fire Unit 09", "Route cleared: Broadway", "15 min ago", Colors.orange),
            _buildActivityItem("System", "Routine check completed", "1 hr ago", Colors.blue),
          ],
        ),
      ),
    );
  }

  // --- HELPER WIDGETS ---

  Widget _buildMapPin({double? top, double? bottom, double? left, double? right, required Color color, required IconData icon}) {
    return Positioned(
      top: top, bottom: bottom, left: left, right: right,
      child: Column(
        children: [
          Icon(icon, color: color, size: 28),
          Container(width: 8, height: 4, decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(100))) // Shadow
        ],
      ),
    );
  }

  Widget _buildGuestStat(String title, String value, Color color, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF151B25), 
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10)
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              Text(title, style: const TextStyle(color: Colors.grey, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActivityItem(String title, String desc, String time, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF151B25), borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          CircleAvatar(radius: 4, backgroundColor: color),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                Text(desc, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              ],
            ),
          ),
          Text(time, style: const TextStyle(color: Colors.white24, fontSize: 11)),
        ],
      ),
    );
  }
}